from flask import Flask, request, render_template, jsonify, session
import os
from datetime import datetime
from fpdf import FPDF
import plotly.express as px
import plotly.io as pio
from flask import send_file
import re
from flask import send_from_directory


app = Flask(__name__)
app.secret_key = os.urandom(24)  # Secret key for session management

# Define folders
CODE_FOLDER = "codes"
SCANNED_FOLDER = "scanned"
os.makedirs(CODE_FOLDER, exist_ok=True)
os.makedirs(SCANNED_FOLDER, exist_ok=True)

# Define references
references = {
    "L0536578": "L0536578_codes.txt",
    "L0658426": "L0658426_codes.txt",
    "L0658427": "L0658427_codes.txt",
    "L0658428": "L0658428_codes.txt",
    "L0536529": "L0536529_codes.txt",
    "L0658542": "L0658542_codes.txt",
    "L0658543": "L0658543_codes.txt",
    "L002371977": "L002371977_codes.txt",
    "L002371979": "L002371979_codes.txt",
    "L002372221": "L002372221_codes.txt",
    "L002372344": "L002372344_codes.txt",
    "L002374220": "L002374220_codes.txt",
}

# Define number of pieces per box (adjust as needed)
pieces_per_box = {
    "L0536578": 16,
    "L0658426": 55,
    "L0658427": 55,
    "L0658428": 32,
    "L0536529": 32,
    "L0658542": 48,
    "L0658543": 32,
    "L002371977": 32,
    "L002371979": 32,
    "L002372221": 55,
    "L002372344": 55,
    "L002374220": 16,
}

# Load and save codes functions
def load_codes(reference):
    """Load codes from the primary file."""
    filepath = os.path.join(CODE_FOLDER, references[reference])
    if os.path.exists(filepath):
        with open(filepath, "r") as file:
            return [line.strip() for line in file]
    return []

def save_codes(reference, codes):
    """Save updated codes to the primary file."""
    filepath = os.path.join(CODE_FOLDER, references[reference])
    with open(filepath, "w") as file:
        file.write("\n".join(codes))

# Load and save scanned codes functions
def load_scanned_codes(reference):
    """Load codes from the scanned file."""
    filepath = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    if os.path.exists(filepath):
        with open(filepath, "r") as file:
            return [line.strip() for line in file]
    return []

def save_scanned_codes(reference, codes):
    """Save updated codes to the scanned file."""
    filepath = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    with open(filepath, "w") as file:
        file.write("\n".join(codes))

def log_code(reference, code):
    """Log the scanned code to the scanned folder."""
    scanned_file = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    with open(scanned_file, "a") as file:
        file.write(code + "\n")

# Entry route - to scan and log codes
@app.route("/entry")
def entry_index():
    return render_template("entry.html")

@app.route("/entry/shift", methods=["POST"])
def set_shift():
    shift = request.form.get('shift')
    if shift:
        session['shift'] = shift  # Store shift in session
        session['start_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Store start time of the shift
        return jsonify({"status": "success", "message": f"Shift set to {shift}. Start scanning now!"})
    return jsonify({"status": "error", "message": "Please select a shift."})

@app.route("/entry/scan", methods=["POST"])
def entry_scan():
    code = request.form.get("code", "").strip()
    if not code:
        return jsonify({"status": "error", "message": "No code entered."})

    for ref in references:
        codes = load_codes(ref)
        if code in codes:
            log_code(ref, code)
            codes.remove(code)
            save_codes(ref, codes)
            return jsonify({"status": "success", "message": f"Code '{code}' logged for {ref}."})

    return jsonify({"status": "error", "message": "Code not found or already scanned."})

# Exit route - to remove scanned codes
@app.route("/exit")
def exit_index():
    return render_template("exit.html")

@app.route("/exit/shift", methods=["POST"])
def set_exit_shift():
    shift = request.form.get('shift')
    if shift:
        session['shift'] = shift  # Store shift in session
        session['start_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Store start time of the shift
        session.permanent = True  # Make the session permanent
        return jsonify({"status": "success", "message": f"Shift set to {shift}. Start scanning now!"})
    return jsonify({"status": "error", "message": "Please select a shift."})

@app.route("/exit/scan", methods=["POST"])
def exit_scan():
    # Get the scanned code from the form
    code = request.form.get("code", "").strip()
    
    # Check if a code was entered
    if not code:
        return jsonify({"status": "error", "message": "No code entered."})

    # Check if shift is set in the session
    if 'shift' not in session:
        return jsonify({"status": "error", "message": "Shift not set. Please set a shift before scanning."})

    # Retrieve the shift and start time from session
    shift = session['shift']
    start_time = session.get('start_time', 'N/A')  # Default to 'N/A' if no start time is available

    # Loop through references to find and remove the scanned code
    for ref in references:
        # Load the scanned codes for the current reference
        scanned_codes = load_scanned_codes(ref)
        
        # Check if the code is in the scanned list
        if code in scanned_codes:
            # Remove the scanned code from the list
            scanned_codes.remove(code)
            
            # Save the updated scanned codes back to the file
            save_scanned_codes(ref, scanned_codes)
            
            # Return success message with shift details
            return jsonify({
                "status": "success",
                "message": f"Code '{code}' removed for {ref}. Shift: {shift}, Start Time: {start_time}."
            })

    # If the code wasn't found or already removed, return an error
    return jsonify({"status": "error", "message": "Code not found or already removed."})

# Summary route - to display scanned code counts and total pieces
@app.route("/summary")
def summary():
    counts = {}
    total_pieces = {}

    for ref, file_name in references.items():
        file_path = os.path.join(SCANNED_FOLDER, f"scanned_{file_name}")
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                scanned_count = len(file.readlines())
        else:
            scanned_count = 0

        # Calculate total pieces: scanned_count * pieces_per_box
        pieces_in_box = pieces_per_box.get(ref, 0)  # Default to 0 if reference is missing
        total_pieces[ref] = scanned_count * pieces_in_box
        counts[ref] = scanned_count

    # Create a Plotly bar chart for the scanned count
    fig = px.bar(
        x=list(counts.keys()),
        y=list(counts.values()),
        labels={'x': 'Reference', 'y': 'Scanned Count'},
        title="Scanned Boxes Summary"
    )
    plot_html = pio.to_html(fig, full_html=False)

    # Return the summary template with the counts and the total pieces
    return render_template('summary.html', counts=counts, total_pieces=total_pieces, plot_html=plot_html)

# Generate PDF report route
@app.route("/generate_report")
def generate_report():
    # Check if shift is selected in the session
    if 'shift' not in session:
        return jsonify({"status": "error", "message": "Shift not selected."})

    # Create a PDF document
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Title
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(200, 10, txt="Shift Report", ln=True, align='C')

    # Add shift and time information
    pdf.set_font("Arial", size=12)
    pdf.ln(10)
    pdf.cell(200, 10, f"Shift: {session['shift']}", ln=True)
    pdf.cell(200, 10, f"Start Time: {session['start_time']}", ln=True)

    # Add scanned codes summary based on what's scanned during the session
    pdf.ln(10)
    pdf.cell(200, 10, "Scanned Codes Summary:", ln=True)

    total_pieces = 0
    scanned_codes_data = []

    for ref, file_name in references.items():
        # Load scanned codes for this reference
        scanned_file_path = os.path.join(SCANNED_FOLDER, f"scanned_{file_name}")
        if os.path.exists(scanned_file_path):
            with open(scanned_file_path, 'r') as file:
                scanned_codes = file.readlines()
                scanned_count = len(scanned_codes)
                pieces_in_box = pieces_per_box.get(ref, 0)
                total_pieces_count = scanned_count * pieces_in_box
                total_pieces += total_pieces_count

                # Prepare data for the report
                scanned_codes_data.append({
                    'ref': ref,
                    'scanned_count': scanned_count,
                    'total_pieces': total_pieces_count
                })
                pdf.cell(200, 10, f"{ref}: {scanned_count} scanned, {total_pieces_count} total pieces", ln=True)

    # Add total pieces to the report
    pdf.ln(10)
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(200, 10, f"Total Pieces Scanned: {total_pieces}", ln=True)

    # Sanitize the shift name and generate the filename
    sanitized_shift = session['shift'].replace(":", "_")  # Replace ':' with '_'
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')  # Add timestamp for uniqueness
    report_filename = f"shift_report_{sanitized_shift}_{timestamp}.pdf"

    # Define the directory where the report will be saved
    report_directory = os.path.join(os.getcwd(), 'static', 'reports')  # Change this to a proper folder

    # Ensure the report directory exists
    os.makedirs(report_directory, exist_ok=True)

    # Save the PDF file to the directory
    report_filepath = os.path.join(report_directory, report_filename)
    pdf.output(report_filepath)

    # Check if the file exists and send it
    if os.path.exists(report_filepath):
        return send_from_directory(report_directory, report_filename, as_attachment=True)
    else:
        return jsonify({"status": "error", "message": "Report generation failed. File not found."})


if __name__ == "__main__":
    app.run(debug=True)
