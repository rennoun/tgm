from flask import Flask, request, render_template, jsonify
import os
import plotly.express as px
import plotly.io as pio

app = Flask(__name__)

# Define folders
CODE_FOLDER = "codes"
SCANNED_FOLDER = "scanned"
os.makedirs(CODE_FOLDER, exist_ok=True)
os.makedirs(SCANNED_FOLDER, exist_ok=True)

# Define references and file names
references = {
    "L0536578": "L0536578_codes.txt",
    "L0658426": "L0658426_codes.txt",
    "L0658427": "L0658427_codes.txt",
    "L0658428": "L0658428_codes.txt",
    "L0536529": "L0536529_codes.txt",
    "L0658542": "L0658542_codes.txt",
    "L0658543": "L0658543_codes.txt",
    "L002371977": "L002371977_codes.txt",
    "L002371979": "L002371979_codes.txt",
    "L002372221": "L002372221_codes.txt",
    "L002372344": "L002372344_codes.txt",
    "L002374220": "L002374220_codes.txt",
}

# Entry routes
def load_codes(reference):
    """Load codes from the primary file."""
    filepath = os.path.join(CODE_FOLDER, references[reference])
    if os.path.exists(filepath):
        with open(filepath, "r") as file:
            return [line.strip() for line in file]
    return []

def save_codes(reference, codes):
    """Save updated codes to the primary file."""
    filepath = os.path.join(CODE_FOLDER, references[reference])
    with open(filepath, "w") as file:
        file.write("\n".join(codes))

def log_code(reference, code):
    """Log the scanned code to the scanned folder."""
    scanned_file = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    with open(scanned_file, "a") as file:
        file.write(code + "\n")

@app.route("/entry")
def entry_index():
    return render_template("entry.html")

@app.route("/entry/scan", methods=["POST"])
def entry_scan():
    code = request.form.get("code", "").strip()
    if not code:
        return jsonify({"status": "error", "message": "No code entered."})

    for ref in references:
        codes = load_codes(ref)
        if code in codes:
            log_code(ref, code)
            codes.remove(code)
            save_codes(ref, codes)
            return jsonify({"status": "success", "message": f"Code '{code}' logged for {ref}."})

    return jsonify({"status": "error", "message": "Code not found or already scanned."})

# Exit routes
def load_scanned_codes(reference):
    """Load codes from the scanned file."""
    filepath = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    if os.path.exists(filepath):
        with open(filepath, "r") as file:
            return [line.strip() for line in file]
    return []

def save_scanned_codes(reference, codes):
    """Save updated codes to the scanned file."""
    filepath = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    with open(filepath, "w") as file:
        file.write("\n".join(codes))

@app.route("/exit")
def exit_index():
    return render_template("exit.html")

@app.route("/exit/scan", methods=["POST"])
def exit_scan():
    code = request.form.get("code", "").strip()
    if not code:
        return jsonify({"status": "error", "message": "No code entered."})

    for ref in references:
        codes = load_scanned_codes(ref)
        if code in codes:
            codes.remove(code)
            save_scanned_codes(ref, codes)
            return jsonify({"status": "success", "message": f"Code '{code}' removed for {ref}."})

    return jsonify({"status": "error", "message": "Code not found or already removed."})

# Summary route
@app.route("/summary")
def summary():
    counts = {}
    for ref, file_name in references.items():
        file_path = os.path.join(SCANNED_FOLDER, file_name)
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                counts[ref] = len(file.readlines())
        else:
            counts[ref] = 0

    # Create a Plotly bar chart
    fig = px.bar(
        x=list(counts.keys()),
        y=list(counts.values()),
        labels={'x': 'Reference', 'y': 'Scanned Count'},
        title="Scanned Boxes Summary"
    )
    plot_html = pio.to_html(fig, full_html=False)

    return render_template('summary.html', counts=counts, plot_html=plot_html)

if __name__ == "__main__":
    app.run(debug=True)
