from flask import Flask, request, render_template, jsonify
import os

app = Flask(__name__)

# Define folders
SCANNED_FOLDER = "scanned"
os.makedirs(SCANNED_FOLDER, exist_ok=True)

# Define references
references = {
    "L0536578": "L0536578_codes.txt",
    "L0658426": "L0658426_codes.txt",
    "L0658427": "L0658427_codes.txt",
    "L0658428": "L0658428_codes.txt",
    "L0536529": "L0536529_codes.txt",
    "L0658542": "L0658542_codes.txt",
    "L0658543": "L0658543_codes.txt",
    "L002371977": "L002371977_codes.txt",
    "L002371979": "L002371979_codes.txt",
    "L002372221": "L002372221_codes.txt",
    "L002372344": "L002372344_codes.txt",
    "L002374220": "L002374220_codes.txt",

    # Add more references
}
def load_scanned_codes(reference):
    """Load codes from the scanned file."""
    filepath = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    if os.path.exists(filepath):
        with open(filepath, "r") as file:
            return [line.strip() for line in file]
    return []

def save_scanned_codes(reference, codes):
    """Save updated codes to the scanned file."""
    filepath = os.path.join(SCANNED_FOLDER, f"scanned_{references[reference]}")
    with open(filepath, "w") as file:
        file.write("\n".join(codes))

@app.route("/")
def exit_index():
    return render_template("exit.html")

@app.route("/scan", methods=["POST"])
def exit_scan():
    code = request.form.get("code", "").strip()
    if not code:
        return jsonify({"status": "error", "message": "No code entered."})

    for ref in references:
        codes = load_scanned_codes(ref)
        if code in codes:
            # Remove the code from the scanned file
            codes.remove(code)
            save_scanned_codes(ref, codes)
            return jsonify({"status": "success", "message": f"Code '{code}' removed for {ref}."})

    return jsonify({"status": "error", "message": "Code not found or already removed."})

if __name__ == "__main__":
    app.run(debug=True)
