from flask import Flask, render_template
import os
import plotly.express as px
import plotly.io as pio

app = Flask(__name__)

# Folder where scanned files are stored
SCANNED_FOLDER = "scanned"

# References and their corresponding scanned file names
references = {
    "L0536578": "scanned_L0536578_codes.txt",
    "L0658426": "scanned_L0658426_codes.txt",
    "L0658427": "scanned_L0658427_codes.txt",
    "L0658428": "scanned_L0658428_codes.txt",
    "L0536529": "scanned_L0536529_codes.txt",
    "L0658542": "scanned_L0658542_codes.txt",
    "L0658543": "scanned_L0658543_codes.txt",
    "L002371977": "scanned_L002371977_codes.txt",
    "L002371979": "scanned_L002371979_codes.txt",
    "L002372221": "scanned_L002372221_codes.txt",
    "L002372344": "scanned_L002372344_codes.txt",
    "L002374220": "scanned_L002374220_codes.txt",
}

@app.route('/summary')
def summary():
    counts = {}
    for ref, file_name in references.items():
        file_path = os.path.join(SCANNED_FOLDER, file_name)
        if os.path.exists(file_path):
            # Count the number of lines in the scanned file
            with open(file_path, 'r') as file:
                counts[ref] = len(file.readlines())
        else:
            counts[ref] = 0

    # Create a Plotly bar chart
    fig = px.bar(
        x=list(counts.keys()),
        y=list(counts.values()),
        labels={'x': 'Reference', 'y': 'Scanned Count'},
        title="Scanned Boxes Summary"
    )
    plot_html = pio.to_html(fig, full_html=False)

    return render_template('summary.html', counts=counts, plot_html=plot_html)

if __name__ == '__main__':
    app.run(debug=True)
